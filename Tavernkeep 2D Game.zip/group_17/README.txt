GAME BINARY INCLUDED IN FOLDER (TavernKeep.apk)

References:
https://www.123rf.com/photo_119466657_stock-vector-wood-texture-brown-plank-wooden-background-in-cartoon-style-vector-illustration-.html
Tabletop source

http://fontsgeek.com/fonts/Copperplate-Gothic-Bold-Regular
Font source

https://bcwhitehead.wordpress.com/tag/cobble-texture/
Cobblestone wall background

https://www.youtube.com/watch?v=uExQKlhx5ms
Beer pour sound

https://www.youtube.com/watch?v=lbuW6zIuUo4
Score increase sound effect

https://www.youtube.com/watch?v=JJLDzJFJsUk
Beer cap sound effect

Pour the pints, or open bottles, and serve to the patrons
To use the tap, drag and hold the handle down, release to stop. Dont overfill the pint.
Use the scraper if pint overfills, then serve
Make sure their patience level isnt exceeded or the game will end