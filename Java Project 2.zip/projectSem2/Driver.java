import java.util.*;
import java.io.*;
public class Driver
{
    public static void main(String[] args) {
        List s = new ArrayList();
        WordSearchPuzzle anInstance = new WordSearchPuzzle(s);
        
    }
}
